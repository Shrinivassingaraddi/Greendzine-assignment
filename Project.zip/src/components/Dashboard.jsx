
// src/components/Dashboard.js
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Line } from 'react-chartjs-2';
import styles from '../styles/App.module.css';

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const Dashboard = () => {
  const navigate = useNavigate();

  const data = {
    labels: ['January', 'February', 'March', 'April', 'May', 'June'],
    datasets: [
      {
        label: 'Sample Data',
        data: [65, 59, 80, 81, 56, 55],
        fill: false,
        backgroundColor: '#007bff',
        borderColor: '#007bff',
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Sample Line Chart',
      },
    },
  };

  const handleLogout = () => {
    // Clear localStorage or relevant data
    localStorage.removeItem('otp');
    localStorage.removeItem('otpExpiry');
    localStorage.removeItem('identifier');
    navigate('/');
  };

  return (
    <div className={styles['dashboard-container']}>
      <h2>Dashboard</h2>
      <Line data={data} options={options} />
      <button onClick={handleLogout}>Logout</button>
    </div>
  );
};

export default Dashboard;

