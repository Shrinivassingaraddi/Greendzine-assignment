// src/components/OTP.js
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const OTP = () => {
  const [enteredOTP, setEnteredOTP] = useState('');
  const [timeLeft, setTimeLeft] = useState(30);
  const navigate = useNavigate();

  useEffect(() => {
    // Countdown timer
    const timer = setInterval(() => {
      const expiry = parseInt(localStorage.getItem('otpExpiry'), 10);
      const now = new Date().getTime();
      const difference = expiry - now;

      if (difference <= 0) {
        clearInterval(timer);
        navigate('/resend-otp');
      } else {
        setTimeLeft(Math.floor(difference / 1000));
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [navigate]);

  const handleVerify = (e) => {
    e.preventDefault();
    const storedOTP = localStorage.getItem('otp');
    const expiry = parseInt(localStorage.getItem('otpExpiry'), 10);
    const now = new Date().getTime();

    if (now > expiry) {
      alert('OTP has expired. Please resend OTP.');
      navigate('/resend-otp');
    } else if (enteredOTP === storedOTP) {
      // OTP is correct
      navigate('/dashboard');
    } else {
      alert('Incorrect OTP. Please try again.');
      navigate('/resend-otp');
    }
  };

  return (
    <div className="otp-container">
      <h2>Enter OTP</h2>
      <p>Time remaining: {timeLeft} seconds</p>
      <form onSubmit={handleVerify}>
        <label>
          OTP:
          <input
            type="text"
            value={enteredOTP}
            onChange={(e) => setEnteredOTP(e.target.value)}
            required
          />
        </label>
        <button type="submit">Verify OTP</button>
      </form>
    </div>
  );
};

export default OTP;
