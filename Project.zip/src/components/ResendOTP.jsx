// src/components/ResendOTP.js
import React from 'react';
import { useNavigate } from 'react-router-dom';

const ResendOTP = () => {
  const navigate = useNavigate();

  const generateOTP = () => {
    return Math.floor(100000 + Math.random() * 900000).toString(); // 6-digit OTP
  };

  const handleResend = () => {
    const otp = generateOTP();
    const expiry = new Date().getTime() + 30 * 1000; // 30 seconds from now

    // Update OTP and expiry in localStorage
    localStorage.setItem('otp', otp);
    localStorage.setItem('otpExpiry', expiry);

    // Optionally notify user
    alert(`Your new OTP is: ${otp}`);

    // Navigate back to OTP verification
    navigate('/otp');
  };

  return (
    <div className="resend-otp-container">
      <h2>OTP Expired</h2>
      <p>Your OTP has expired. Please resend to continue.</p>
      <button onClick={handleResend}>Resend OTP</button>
    </div>
  );
};

export default ResendOTP;
