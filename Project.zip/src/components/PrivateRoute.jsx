// src/components/PrivateRoute.js
import React from 'react';
import { Navigate } from 'react-router-dom';

const PrivateRoute = ({ children }) => {
  const otp = localStorage.getItem('otp');
  const otpExpiry = localStorage.getItem('otpExpiry');
  const now = new Date().getTime();

  if (otp && otpExpiry && now < parseInt(otpExpiry, 10)) {
    return children;
  } else {
    return <Navigate to="/" />;
  }
};

export default PrivateRoute;
