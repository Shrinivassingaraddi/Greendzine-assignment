// src/components/Login.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from '../styles/App.module.css'; // Adjust the path as needed

const Login = () => {
  const [identifier, setIdentifier] = useState('');
  const navigate = useNavigate();

  const generateOTP = () => {
    return Math.floor(100000 + Math.random() * 900000).toString(); // 6-digit OTP
  };

  const handleLogin = (e) => {
    e.preventDefault();
    const otp = generateOTP();
    const expiry = new Date().getTime() + 30 * 1000; // 30 seconds from now

    // Store OTP and expiry in localStorage
    localStorage.setItem('otp', otp);
    localStorage.setItem('otpExpiry', expiry);

    // Optionally store user identifier
    localStorage.setItem('identifier', identifier);

    // Display OTP as alert
    alert(`Your OTP is: ${otp}`);

    // Navigate to OTP verification page
    navigate('/otp');
  };

  return (
    <div className={styles['login-container']}>
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <label>
          Email or Phone:
          <input
            type="text"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            required
          />
        </label>
        <button type="submit">Send OTP</button>
      </form>
    </div>
  );
};

export default Login;
